from google.appengine.ext import db
from google.appengine.api import memcache
from google.appengine.api import users
from time import sleep
import random
import string

print "Content-Type: text/plain"
print ""

print "Clearing out memcache"
print memcache.flush_all()

print "\nis \"key\" in memcache? expecting \"None\""
print memcache.get("key")

print "putting in \"key\" with value \"val\" and lifetime 1 second"
print memcache.set("key", "val", 1)

print "getting \"key\", expecting value \"val\""
print memcache.get("key")

print "\nputting in \"counter\" with value 1"
print memcache.set("counter", 1)

print "getting \"counter\", expecting value 1"
print memcache.get("counter")

print "\nincrementing \"counter\" by 5, expecting 6"
print memcache.incr("counter", 5)

print "decrementing \"counter\" by 3, expecting 3"
print memcache.decr("counter", 3)

print "\nsleeping for 4 seconds"
sleep(4)
print "now that >1 second has passed, \"key\" shouldn't be in cache"
print "expecting None"
print memcache.get("key")

print "\ndeleting \"counter\""
print memcache.delete("counter")

print "getting \"counter\", expecting \"None\""
print memcache.get("counter")

print "\noh by the way here are some stats"
stats = memcache.get_stats()
print "Cache Hits: " + str(stats['hits'])
print "Cache Misses: " + str(stats['misses'])
print "Byte Hits: " + str(stats['byte_hits'])
print "Items in Cache: " + str(stats['items'])
print "Size of Items in Cache: " + str(stats['bytes'])
print "Age of Oldest Item: " + str(stats['oldest_item_age'])
